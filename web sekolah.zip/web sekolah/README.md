# Hello World TypeScript Project

This is a simple Hello World project written in TypeScript.

## How to Run

1. Compile the TypeScript file:
   ```powershell
   npx tsc
   ```
2. Run the compiled JavaScript:
   ```powershell
   node index.js
   ```

You should see:
```
Hello World
```
